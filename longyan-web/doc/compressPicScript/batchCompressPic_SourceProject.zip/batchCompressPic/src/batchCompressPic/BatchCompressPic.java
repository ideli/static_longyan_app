package batchCompressPic;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.PropertyResourceBundle;

import javax.imageio.ImageIO;

import org.im4java.core.ConvertCmd;
import org.im4java.core.IM4JavaException;
import org.im4java.core.IMOperation;

public class BatchCompressPic {

	static int width;
	static int height;
	static int icon_width;
	static int icon_height;
	static String defaultLocation = "e:\\";
    static String windowsIM4Location;
	static boolean ifWindows = false;

	public static void main(String[] args) {

		String filePath = null;
		String fileName = null;
		String destFilePath = null;
		String icon_destFilePath = null;
		if (args.length != 0) {
			if (args[0].equals("ios")) {
				width = 640;
				height = 1136;
				icon_height = 360;
				icon_width = 360;
			} else if (args[0].equals("android")) {
				width = 2160;
				height = 3840;
				icon_height = 946;
				icon_width = 946;
			} else if (args[0].equals("web")) {
				width = 100;
				height = 100;
			}
		} else {
			args = new String[] { "web" };
		}
		try {
			PropertyResourceBundle properties = new PropertyResourceBundle(
					new FileReader(new File("config.properties")));
			defaultLocation = properties.getString("imgLocation");
            windowsIM4Location=properties.getString("im4javaLocation");
			ifWindows = properties.getString("ifWindows").equals("true") ? true
					: false;
			width = Integer.parseInt(properties.getString(
					args[0].toUpperCase().concat("_").concat("WIDTH")).trim());
			height = Integer.parseInt(properties.getString(
					args[0].toUpperCase().concat("_").concat("HEIGHT")).trim());
			icon_height = Integer.parseInt(properties.getString(
					args[0].toUpperCase().concat("_").concat("ICON_HEIGHT"))
					.trim());
			icon_width = Integer.parseInt(properties.getString(
					args[0].toUpperCase().concat("_").concat("ICON_HEIGHT"))
					.trim());
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		ConvertCmd cmd = new ConvertCmd();
		if (ifWindows) {
			cmd.setSearchPath(windowsIM4Location);
		}

		File picDeirctory = new File(defaultLocation);
		List<String[]> filePathLists = new ArrayList<String[]>();
		if (picDeirctory.isDirectory()) {
			File[] files = picDeirctory.listFiles();
			for (int i = 0; i < files.length; i++) {
				if (files[i].isFile()) {
					filePath = files[i].getPath();
					fileName = files[i].getName();
					if (fileName.indexOf("_") == -1
							&& (fileName.indexOf("png") != -1
									|| fileName.indexOf("gif") != -1 || fileName
									.indexOf("jpg") != -1)) {
						String[] nameType = fileName.split("\\.");
						destFilePath = defaultLocation.concat(File.separator).concat(nameType[0])
								.concat("_").concat(args[0]).concat(".")
								.concat(nameType[1]);
						icon_destFilePath = defaultLocation.concat(File.separator).concat(nameType[0])
								.concat("_").concat("icon").concat("_")
								.concat(args[0]).concat(".")
								.concat(nameType[1]);
						String[] filePathArray = new String[3];
						filePathArray[0] = filePath;
						filePathArray[1] = destFilePath;
						filePathArray[2] = icon_destFilePath;
						filePathLists.add(filePathArray);
					}

				}

			}
		}

		int total = filePathLists.size();
		int current = 1;
		for (String[] filePathArray : filePathLists) {
			try {
				System.out.println(args[0]+" total:"+total+"; current:"+current);
				IMOperation op = new IMOperation();
				op.addImage(filePathArray[0]);
				op.resize(width, height);
				op.addImage(filePathArray[1]);
				//缩略图
	            BufferedImage srcImg=ImageIO.read(new File(filePathArray[0]));
	            int srcWidth=srcImg.getWidth();
	            int srcHeight=srcImg.getHeight();
				IMOperation icon_op = new IMOperation();
				icon_op.addImage(filePathArray[0]);
		        if(srcHeight>srcWidth){
		        	icon_op.crop(srcWidth,srcWidth,0,(srcHeight-srcWidth)/2);
		        }
		        if(srcHeight<srcWidth){
		        	icon_op.crop(srcHeight,srcHeight,(srcWidth-srcHeight)/2,0);
		        }
				icon_op.resize(icon_width, icon_height);
				icon_op.addImage(filePathArray[2]);
			
				cmd.run(op);
				if("web"!=args[0]){
					cmd.run(icon_op);
				}
			} catch (IOException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (IM4JavaException e) {
				e.printStackTrace();
			}
			current++;
		}

	}
	

}
