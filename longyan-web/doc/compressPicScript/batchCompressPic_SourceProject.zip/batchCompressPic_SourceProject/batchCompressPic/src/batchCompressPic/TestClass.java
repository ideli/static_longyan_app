package batchCompressPic;

import java.io.IOException;

import org.im4java.core.ConvertCmd;
import org.im4java.core.IM4JavaException;
import org.im4java.core.IMOperation;

public class TestClass {
	public static void convert(String src, String desc, int width, int height)
    {
        ConvertCmd cmd = new ConvertCmd();
        String imPath="V:\\programe files\\ImageMagick-6.8.8-Q16\\";
        cmd.setSearchPath(imPath);
        IMOperation op = new IMOperation();
        op.addImage();
        op.resize(width, height);
        op.addImage();

        try {
            cmd.run(op, src, desc);
        }
        catch (IOException e) {
            e.printStackTrace();

        }
        catch (InterruptedException e) {
            e.printStackTrace();

        }
        catch (IM4JavaException e) {
            e.printStackTrace();
        }
    }
	public static void main(String[] args){
		String src="v:\\test1.jpg";
		String desc="v:\\test2.jpg";
		convert(src,desc,100,100);
	}
}
