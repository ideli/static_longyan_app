package batchCompressPic;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.PropertyResourceBundle;

import javax.imageio.ImageIO;

import org.im4java.core.ConvertCmd;
import org.im4java.core.IM4JavaException;
import org.im4java.core.IMOperation;

public class BatchCompressPic {

	static int width;
	static int height;
	static int icon_width;
	static int icon_height;
	static String defaultLocation = "e:\\";
    static String windowsIM4Location;
	static boolean ifWindows = false;
	static String dbUrl;
	static String dbUser;
	static String dbUserPwd;
	static PropertyResourceBundle properties;
	static List<String> dbPicList=new ArrayList<String>();
	static{
		System.out.println("init storages");
		try {
			properties = new PropertyResourceBundle(
					new FileReader(new File("config.properties")));	
			dbUrl=properties.getString("dbUrl");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		Connection conn=getConnection();
		Statement st=null;
		ResultSet rs=null;
		try {
			String sql = "select a.storeName from xiwa_base_storage a where a.`fileType` in ('png','jpg','gif');"; // 查询数据的sql语句
			st = (Statement) conn.createStatement(); // 创建用于执行静态sql语句的Statement对象，st属局部变量
			rs = st.executeQuery(sql); //执行sql查询语句，返回查询数据的结果集
			while (rs.next()) {	// 判断是否还有下一个数据				
				// 根据字段名获取相应的值
				String name = rs.getString("storeName").trim();
				dbPicList.add(name);		
			}
			System.out.println("done init dbstorages--file list:"+dbPicList.size());
		} catch (SQLException e) {
			System.out.println("查询数据失败");
		} finally {
			try {
				if(rs!=null){
					rs.close();
				}
				if(st!=null){
					st.close();
				}
				if(conn!=null){
					conn.close();
				}
			} catch (SQLException e) {
				System.out.println("数据库资源释放失败" + e.getMessage());
			}

		}
		
	}

	public static Connection getConnection() {
		Connection con = null;	
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(dbUrl);
			
		} catch (Exception e) {
			System.out.println("数据库连接失败" + e.getMessage());
		}
		return con;	
	}

	public static void main(String[] args) {

		String filePath = null;
		String fileName = null;
		String destFilePath = null;
		String icon_destFilePath = null;
		if (args.length != 0) {
			if (args[0].equals("ios")) {
				width = 640;
				height = 1136;
				icon_height = 360;
				icon_width = 360;
			} else if (args[0].equals("android")) {
				width = 2160;
				height = 3840;
				icon_height = 946;
				icon_width = 946;
			} else if (args[0].equals("web")) {
				width = 100;
				height = 100;
			}
		} else {
			args = new String[] { "web" };
		}
		defaultLocation = properties.getString("imgLocation");
		windowsIM4Location=properties.getString("im4javaLocation");
		ifWindows = properties.getString("ifWindows").equals("true") ? true
				: false;
		width = Integer.parseInt(properties.getString(
				args[0].toUpperCase().concat("_").concat("WIDTH")).trim());
		height = Integer.parseInt(properties.getString(
				args[0].toUpperCase().concat("_").concat("HEIGHT")).trim());
		icon_height = Integer.parseInt(properties.getString(
				args[0].toUpperCase().concat("_").concat("ICON_HEIGHT"))
				.trim());
		icon_width = Integer.parseInt(properties.getString(
				args[0].toUpperCase().concat("_").concat("ICON_HEIGHT"))
				.trim());		
		
		ConvertCmd cmd = new ConvertCmd();
		if (ifWindows) {
			cmd.setSearchPath("V:"+File.separator+"programe files"+File.separator+"ImageMagick-6.8.8-Q16");
		}

		File picDeirctory = new File(defaultLocation);
		List<String[]> filePathLists = new ArrayList<String[]>();
		if (picDeirctory.isDirectory()) {
			File[] files = picDeirctory.listFiles();
			for (int i = 0; i < files.length; i++) {
				if (files[i].isFile() & dbPicList.contains(files[i].getName())) {
					filePath = files[i].getPath();
					fileName = files[i].getName();
					if (fileName.indexOf("_") == -1
							&& (fileName.indexOf("png") != -1
									|| fileName.indexOf("gif") != -1 || fileName
									.indexOf("jpg") != -1)) {
						String[] nameType = fileName.split("\\.");
						destFilePath = defaultLocation.concat(File.separator)
								.concat(nameType[0]).concat("_")
								.concat(args[0]).concat(".")
								.concat(nameType[1]);
						icon_destFilePath = defaultLocation
								.concat(File.separator).concat(nameType[0])
								.concat("_").concat("icon").concat("_")
								.concat(args[0]).concat(".")
								.concat(nameType[1]);
						String[] filePathArray = new String[3];
						filePathArray[0] = filePath;
						filePathArray[1] = destFilePath;
						filePathArray[2] = icon_destFilePath;
						filePathLists.add(filePathArray);
					}
				}
			}
		}

		int total = filePathLists.size();
		int current = 1;
		for (String[] filePathArray : filePathLists) {
			try {
				System.out.println("------------------------------------------------------------");
				System.out.println(args[0]+" total:"+total+"; current:"+current+"---begin");
	            BufferedImage srcImg=ImageIO.read(new File(filePathArray[0]));
	            if(srcImg==null){
	            	continue;
	            }
	            File file1=new File(filePathArray[1]);
				if(!file1.exists()){
					IMOperation op = new IMOperation();
					op.addImage(filePathArray[0]);
					op.resize(width, height);
					op.addImage(filePathArray[1]);
					cmd.run(op);
					System.out.println("    file generation done:"+file1.getName());
				}else{
					System.out.println("    file already  exists:"+file1.getName());
				}
				File file2=new File(filePathArray[2]);
	            if(!file2.exists()){
		            int srcWidth=srcImg.getWidth();
		            int srcHeight=srcImg.getHeight();
					IMOperation icon_op = new IMOperation();
					icon_op.addImage(filePathArray[0]);
			        if(srcHeight>srcWidth){
			        	icon_op.crop(srcWidth,srcWidth,0,(srcHeight-srcWidth)/2);
			        }
			        if(srcHeight<srcWidth){
			        	icon_op.crop(srcHeight,srcHeight,(srcWidth-srcHeight)/2,0);
			        }
					icon_op.resize(icon_width, icon_height);
					icon_op.addImage(filePathArray[2]);
				    cmd.run(icon_op);
				    System.out.println("    file generation done:"+file2.getName());
	            }else{
					System.out.println("    file already  exists:"+file2.getName());
				}
				System.out.println(args[0]+" total:"+total+"; current:"+current+"---finish");
			} catch (IOException e) {
				e.printStackTrace();
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (IM4JavaException e) {
				e.printStackTrace();
			}
			current++;
		}

	}
	

}
